let list1=['Hyderabad','Bangalore','Chennai','Delhi','Pune','Kolkata'];
let list2=['Gujarat','Pune','Rajasthan','Bangalore','Vizag','Delhi']; 
let uniqueList1=[],uniqueList2=[],commonUsers=[]

for (let i=0;i<list1.length;i++){
    let found=false;
    for (let j=0;j<list2.length;j++){
        if(list1[i]===list2[j]) {
            found=true;
            break;
        }
    }
    if (!found)uniqueList1.push(list1[i]);
}
console.log(uniqueList1);

for (let i=0;i<list2.length;i++){
    let found=false;
    for (let j=0;j<list1.length;j++){
        if(list2[i]===list1[j]){
            found=true;
            break;
        }
    }
    if (!found)uniqueList2.push(list2[i]);
}
console.log(uniqueList2);
for (let i=0;i<list1.length;i++){
    let found=false;
    for (let j=0;j<list2.length;j++){
        if(list1[i]===list2[j]){
            commonUsers.push(list1[i]);
            break;
        }
    }
    
}
console.log(commonUsers);